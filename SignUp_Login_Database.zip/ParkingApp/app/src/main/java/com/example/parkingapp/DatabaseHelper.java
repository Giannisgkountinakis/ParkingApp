package com.example.parkingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME ="authentication.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_SIGNUP = "signup";

    // Fields of signup table
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    private static final String CREATE_TABLE_SIGNUP = "CREATE TABLE " + TABLE_SIGNUP + " (" +
            COLUMN_NAME + " TEXT, " +
            COLUMN_EMAIL + " TEXT PRIMARY KEY, " +
            COLUMN_PASSWORD + " TEXT);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_SIGNUP);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SIGNUP);
        onCreate(sqLiteDatabase);
    }

    // Μέθοδος για εισαγωγή δεδομένων
    public boolean insertSignupData(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, name);
        contentValues.put(COLUMN_EMAIL, email);
        contentValues.put(COLUMN_PASSWORD, password);
        try {
            long result = db.insert(TABLE_SIGNUP, null, contentValues);
            return result != -1; // Επιστρέφει true αν η εισαγωγή ήταν επιτυχής
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Μέθοδος για επαλήθευση χρήστη
    public boolean validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM signup WHERE email = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});

        boolean isValid = cursor.getCount() > 0; // Αν βρεθεί χρήστης, το αποτέλεσμα είναι >0
        cursor.close();
        return isValid;
    }
}
