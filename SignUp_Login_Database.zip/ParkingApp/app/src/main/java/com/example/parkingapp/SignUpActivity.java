package com.example.parkingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

//public class SignUpActivity extends AppCompatActivity {
//
//    private static ArrayList<User> registeredUsers = new ArrayList<>();
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_sign_up);
//
//        EditText insertName = findViewById(R.id.insertName);
//        EditText insertEmail = findViewById(R.id.inserttEmail);
//        EditText insertPassword = findViewById(R.id.insertPassword);
//
//        Button signupButton = findViewById(R.id.signUp);
//
//        signupButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // Παίρνουμε τις τιμές από τα EditText
//                String name = insertName.getText().toString().trim();
//                String email = insertEmail.getText().toString().trim();
//                String password = insertPassword.getText().toString().trim();
//
//
//                //Add a new register in the array
//                registeredUsers.add(new User(name, password, email));
//                Toast.makeText(getApplicationContext(), "User registered successfully!", Toast.LENGTH_SHORT).show();
//            }
//
//        });
//    }
//
//    public static ArrayList<User> RegisteredUsers(){
//        return registeredUsers;
//    }
//}

public class SignUpActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Αρχικοποίηση του DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        EditText insertName = findViewById(R.id.insertName);
        EditText insertEmail = findViewById(R.id.inserttEmail);
        EditText insertPassword = findViewById(R.id.insertPassword);

        Button signupButton = findViewById(R.id.signUp);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Παίρνουμε τις τιμές από τα EditText
                String name = insertName.getText().toString().trim();
                String email = insertEmail.getText().toString().trim();
                String password = insertPassword.getText().toString().trim();

                // Εισαγωγή δεδομένων στη βάση
                boolean isInserted = dbHelper.insertSignupData(name, email, password);

                if (isInserted) {
                    Toast.makeText(getApplicationContext(), "User registered successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: Registration failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

