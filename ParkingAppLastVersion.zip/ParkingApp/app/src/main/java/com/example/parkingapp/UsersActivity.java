package com.example.parkingapp;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.ArrayList;

public class UsersActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        LinearLayout container = findViewById(R.id.usersContainer);

        databaseHelper = new DatabaseHelper(this);
        ArrayList<User> registeredUsers = databaseHelper.getAllUsers();





        if(registeredUsers.size() > 0) {

            for (User user : registeredUsers) {

                TextView nameText = new TextView(this);
                CardView usersCardView = new CardView(this);

                nameText.setText(user.getName() );
                nameText.setTextSize(24);
                nameText.setTextColor(Color.BLACK);
                nameText.setTypeface(null, Typeface.BOLD);
                nameText.setPadding(16, 16, 16, 16);


                usersCardView.setRadius(16);
                usersCardView.setElevation(4);

                LinearLayout.LayoutParams cardParmeters = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

                cardParmeters.setMargins(16, 24, 16, 24);
                usersCardView.setLayoutParams(cardParmeters);
                usersCardView.addView(nameText);
                container.addView(usersCardView);

            }
        }
        else{

            TextView nameText = new TextView(this);
            CardView usersCardView = new CardView(this);

            nameText.setText("There are not registered users yet");
            nameText.setTextSize(24);
            nameText.setTextColor(Color.BLACK);
            nameText.setTypeface(null, Typeface.BOLD);
            nameText.setPadding(16,16,16,16);

            usersCardView.setRadius(16);
            usersCardView.setElevation(16);

            LinearLayout.LayoutParams cardParmeters = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );

            cardParmeters.setMargins(16,24,16,24);
            usersCardView.setLayoutParams(cardParmeters);
            usersCardView.addView(nameText);
            container.addView(usersCardView);

        }
    }
}
