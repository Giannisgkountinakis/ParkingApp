package com.example.parkingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.example.parkingapp.databinding.ActivityMapsBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;

public class AdminMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

       /* if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        }

        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15)); // 15 = zoom level
                    }
                });
*/

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
        }
        else{
            mMap.setMyLocationEnabled(true);
        }

        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 150));
                }
            }
        });
        LatLng parking1 = new LatLng(37.9838, 23.7275); // Αθήνα
        LatLng parking2 = new LatLng(37.9904, 23.73211); // Κοντινό σημείο

        mMap.addMarker(new MarkerOptions().position(parking1).title("Parking A"));
        mMap.addMarker(new MarkerOptions().position(parking2).title("Parking B"));


        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(parking1);
        builder.include(parking2);
// πρόσθεσε όσα άλλα parking έχεις

        LatLngBounds bounds = builder.build();
        int padding = 100; // pixels
        mMap.setOnMapLoadedCallback(() -> {
            mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
        });

        // Reference to the LinearLayout
        LinearLayout locationsContainer = findViewById(R.id.locationsContainer);


// Δημιουργία τοποθεσιών με όνομα και συντεταγμένες
        String[] names = {"Omonoia ", "Glyfada"};
        LatLng[] positions = {
                new LatLng(37.9838, 23.7275),
                new LatLng(37.9904, 23.73211)
        };

// Προσθήκη markers
        for (int i = 0; i < names.length; i++) {
            mMap.addMarker(new MarkerOptions().position(positions[i]).title(names[i]));
        }

// Προσθήκη TextViews δυναμικά με click listeners
        for (int i = 0; i < names.length; i++) {
            final int index = i;

            // Δημιουργία CardView
            CardView card = new CardView(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            layoutParams.setMargins(16, 8, 16, 8);
            card.setLayoutParams(layoutParams);
            card.setRadius(16);
            card.setCardElevation(4);
            card.setUseCompatPadding(true);
            card.setPreventCornerOverlap(true);

            // Σχεδιασμός περιγράμματος
            GradientDrawable background = new GradientDrawable();
            background.setColor(Color.parseColor("#FFFFFF")); // Λευκό background
            background.setCornerRadius(16);
            background.setStroke(2, Color.parseColor("#2196F3")); // Λεπτό μπλε περίγραμμα
            card.setBackground(background);

            // TextView
            TextView textView = new TextView(this);
            textView.setText(names[i]);
            textView.setTextSize(16); // Πιο μικρό
            textView.setTypeface(null, Typeface.BOLD);
            textView.setTextColor(Color.parseColor("#212121"));
            textView.setPadding(24, 16, 24, 16); // Πιο συμπαγές padding

            card.addView(textView);

            // On click → zoom στον χάρτη
            card.setOnClickListener(v -> {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(positions[index], 16));
            });

            locationsContainer.addView(card);
        }




    }
}