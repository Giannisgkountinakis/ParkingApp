package com.example.parkingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;


//WORKING CODE
//public class LoginActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_login);
//
//        EditText insertEmail = findViewById(R.id.emailInput);
//        EditText insertPassword = findViewById(R.id.passwordInput);
//
//        Button logInButton = findViewById(R.id.loginbtn);
//
//
//
//        logInButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String email = insertEmail.getText().toString().trim();
//                String password = insertPassword.getText().toString().trim();
//
//                ArrayList<User> registeredUsers = SignUpActivity.RegisteredUsers();
//
//                for (int i=0; i<registeredUsers.size(); i++) {
//
//                    //Checks if the username that the user entered exists
//                    boolean correctEmail = registeredUsers.get(i).hasEmail(email);
//                    if (correctEmail) {
//                        //Checks if the password that the user entered exists for the username
//                        boolean correctPassword = registeredUsers.get(i).hasPassword(password);
//                        if (correctPassword){
//                            //System.out.println("Success login");
//                            Toast.makeText(getApplicationContext(),"Welcome!",Toast.LENGTH_SHORT).show();
//                        }
//                        else {
//                            //System.out.println("Incorrect password");
//                            Toast.makeText(getApplicationContext(),"Incorrect password",Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                    else {
//                        System.out.println("Incorrect username or password");
//                        Toast.makeText(getApplicationContext(),"Incorrect username or password",Toast.LENGTH_SHORT).show();
//                    }
//
//                }
//            }
//        });
//    }
//}


public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Αρχικοποίηση DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        EditText insertEmail = findViewById(R.id.emailInput);
        EditText insertPassword = findViewById(R.id.passwordInput);
        Button logInButton = findViewById(R.id.loginbtn);
        Button BackBtnLogin = findViewById(R.id.BtnBackLogin);

        BackBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentStartPage = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intentStartPage);
            }
        });

        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = insertEmail.getText().toString().trim();
                String password = insertPassword.getText().toString().trim();

                // Έλεγχος αν τα credentials είναι σωστά
                boolean isValidUser = dbHelper.validateUser(email, password);

                if (isValidUser && email.equals("admin@gmail.com") ) {
                    Toast.makeText(getApplicationContext(), "Welcome admin!", Toast.LENGTH_SHORT).show();
                    Intent adminPageIntent = new Intent(LoginActivity.this, AdminMain.class);
                    startActivity(adminPageIntent);
                }
                else if (isValidUser){
                    Toast.makeText(getApplicationContext(), "Welcome!", Toast.LENGTH_SHORT).show();
                    Intent mainPageIntent = new Intent(LoginActivity.this, MapsActivity.class);
                    startActivity(mainPageIntent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Incorrect username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}