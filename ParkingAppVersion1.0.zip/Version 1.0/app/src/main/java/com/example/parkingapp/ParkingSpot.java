package com.example.parkingapp;

import java.time.LocalTime;

public class ParkingSpot {
    private int id;
    private double latitude;
    private double longitude;



    private double pricePerHour;
    private LocalTime startTime;
    private LocalTime endTime;

    public boolean isAvailable;

    public ParkingSpot(int ID, double latitude, double longitude, double pricePerHour, LocalTime startTime, LocalTime endTime, boolean isAv) {
        this.id = ID;
        this.latitude = latitude;
        this.longitude = longitude;
        this.pricePerHour = pricePerHour;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isAvailable = isAv;
    }
    public int getId() {
        return id;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getPricePerHour() {
        return pricePerHour;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }
}
