package com.example.parkingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class AdminMain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
/*

        Admin admin = new Admin("admin@gmail.com",  "4357atletico");

        ParkingSpot spot1 = new ParkingSpot("Spot1", "1.0", true, "Ethnikis Amunhs",24,"8:00 -23:00");
        ParkingSpot spot2 = new ParkingSpot("Spot1", "1.0", true, "Ethnikis Amunhs",24,"8:00 -23:00");
        ParkingSpot spot3 = new ParkingSpot("Spot1", "1.0", true, "Ethnikis Amunhs",24,"8:00 -23:00");
        ParkingSpot spot4 = new ParkingSpot("Spot1", "1.0", true, "Ethnikis Amunhs",24,"8:00 -23:00");

        admin.addParkingSpot(spot1);
        admin.addParkingSpot(spot2);
        admin.addParkingSpot(spot3);
        admin.addParkingSpot(spot4);

        admin.applyUpdates();
*/
        CardView parkingLocations = findViewById(R.id.cardViewParking);
        parkingLocations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminMain.this, AdminMapsActivity.class);
                startActivity(intent);
            }
        });

        CardView users = findViewById(R.id.cardViewUsers);
        users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminMain.this,UsersActivity.class);
                startActivity(intent);
            }
        });

        CardView cardViewRevenue = findViewById(R.id.cardViewRevenue);
        cardViewRevenue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminMain.this,Revenue.class);
                startActivity(intent);
            }
        });







    }
}