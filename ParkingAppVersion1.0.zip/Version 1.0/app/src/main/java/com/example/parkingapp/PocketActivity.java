package com.example.parkingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class PocketActivity extends AppCompatActivity {

    private TextView txtBalance;
    private Button btnAdd5, btnAdd10, btnAdd20, btnBack;
    private ListView listTransactions;

    private double balance = 0.0;
    private ArrayList<String> transactions;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pocket_main);

        double walletAmount = getIntent().getDoubleExtra("walletAmount", 0.0);
        balance = walletAmount;

        txtBalance = findViewById(R.id.txtBalance);
        btnAdd5 = findViewById(R.id.btnAdd5);
        btnAdd10 = findViewById(R.id.btnAdd10);
        btnAdd20 = findViewById(R.id.btnAdd20);
        btnBack = findViewById(R.id.btnBack);
        listTransactions = findViewById(R.id.listTransactions);

        // Φόρτωσε τις αποθηκευμένες συναλλαγές από SharedPreferences
        SharedPreferences prefs = getSharedPreferences("walletPrefs", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString("transactionList", null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        transactions = gson.fromJson(json, type);
        if (transactions == null) {
            transactions = new ArrayList<>();
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, transactions);
        listTransactions.setAdapter(adapter);

        updateBalance();

        btnAdd5.setOnClickListener(v -> addMoney(5));
        btnAdd10.setOnClickListener(v -> addMoney(10));
        btnAdd20.setOnClickListener(v -> addMoney(20));

        btnBack.setOnClickListener(view -> {
            Intent returnIntent = new Intent();
            returnIntent.putExtra("walletAmount", balance);
            setResult(RESULT_OK, returnIntent);
            finish();
        });
        Button btnClear = findViewById(R.id.btnClear);

        btnClear.setOnClickListener(v -> {
            transactions.clear();
            adapter.notifyDataSetChanged();

            SharedPreferences pref = getSharedPreferences("walletPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            editor.remove("transactionList"); // Διαγραφή του ιστορικού
            editor.apply();
        });

        Button btnLogout = findViewById(R.id.logoutButton);

        btnLogout.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PocketActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void addMoney(double amount) {
        balance += amount;
        String transaction = "+ " + amount + "€ | " + getCurrentDate();
        transactions.add(transaction);
        adapter.notifyDataSetChanged();
        updateBalance();

        // Αποθήκευση των αλλαγών στο SharedPreferences
        SharedPreferences prefs = getSharedPreferences("walletPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(transactions);
        editor.putString("transactionList", json);
        editor.putFloat("balance", (float) balance); // Προαιρετικά αποθήκευση υπολοίπου
        editor.apply();
    }

    public void updateBalance() {
        txtBalance.setText("Υπόλοιπο: " + String.format("%.2f", balance) + "€");
    }

    public String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(new Date());
    }
}

