package com.example.parkingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;


import com.example.parkingapp.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    private Map<Marker, ParkingSpot> markerParkingSpotMap;

    private TextView tvId;
    private TextView tvHours;
    private TextView tvAvailability;
    private TextView tvPrice;
    private Button btnRes;
    private BottomSheetBehavior<View> bottomSheetBehavior;

    private PocketActivity wallet;
    private double walletAmount = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        //bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        View bottomSheet = findViewById(R.id.bottom_sheet_layout_include);

        tvId = bottomSheet.findViewById(R.id.tvId);
        tvHours = bottomSheet.findViewById(R.id.tvHours);
        tvPrice = bottomSheet.findViewById(R.id.tvPrice);
        tvAvailability = bottomSheet.findViewById(R.id.tvAvailability);
        btnRes = bottomSheet.findViewById(R.id.btnRes);



        // Αρχικοποίηση του BottomSheet UI
       /*View bottomSheet = findViewById(R.id.bottom_sheet_layout_include); // Το ID του include tag
            bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
            //bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        tvSpotId = bottomSheet.findViewById(R.id.tvId);
        tvSpotHours = bottomSheet.findViewById(R.id.tvHours);
        tvSpotPrice = bottomSheet.findViewById(R.id.tvPrice);
        tvSpotAvailability = bottomSheet.findViewById(R.id.tvAvailability);
       btnRes = bottomSheet.findViewById(R.id.btnRes); */
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        markerParkingSpotMap = new HashMap<>();



        ArrayList<ParkingSpot> allpSpots = new ArrayList<>();

        LatLng[] coordinates = {
                new LatLng(21.311414, -157.860279),
                new LatLng(21.311253, -157.860421),
                new LatLng(21.311194, -157.860500),
                new LatLng(21.312390, -157.864321),
                new LatLng(21.310559, -157.861581),
                new LatLng(21.311182, -157.862119),
                new LatLng(21.311386, -157.862253),
                new LatLng(21.311621, -157.862406),
                new LatLng(21.311685, -157.862449),
                new LatLng(21.3060,   -157.8595),
                new LatLng(21.3068,   -157.8570),
                new LatLng(21.306216, -157.857590),
                new LatLng(21.310559, -157.861581),
                new LatLng(21.305638, -157.857344),
                new LatLng(21.308663, -157.857276),
                new LatLng(21.308522, -157.858057)
        };


        int[] costs =     {3, 5,10, 4, 3, 5,10, 2,10, 5,10, 5, 4, 6, 3, 4};
        int[] startHours ={8,10, 9, 7, 8,10, 9, 7, 8,10, 9, 7, 8,10, 9, 7};
        int[] endHours =  {20,21,23,22,20,21,23,22,20,21,23,22,20,21,23,22};
        boolean[] occupied={false,true,false,true,true,false,true,false,true,true,true,false,true,true,false,true};

        for (int i = 0; i < coordinates.length; i++) {
            LatLng c = coordinates[i];
            int id = 1000 + i;
            ParkingSpot spot = new ParkingSpot(
                    id,
                    c.latitude,
                    c.longitude,
                    costs[i],
                    LocalTime.of(startHours[i], 0),
                    LocalTime.of(endHours[i], 0),
                    occupied[i]
            );
            allpSpots.add(spot);
        }

        for(ParkingSpot spot: allpSpots){
            LatLng location = new LatLng(spot.getLatitude(), spot.getLongitude());
            Marker marker = mMap.addMarker(new MarkerOptions().position(location).title("Θέση: " + spot.getId() + " τιμή: "+ spot.getPricePerHour() +"€"));

            markerParkingSpotMap.put(marker, spot); // Συσχέτιση marker με ParkingSpot
        }
        // Μετακίνηση της κάμερας σε μια αρχική θέση ή προσαρμογή το zoom
        if (!allpSpots.isEmpty()) {
            LatLng firstLocation = new LatLng(allpSpots.get(0).getLatitude(), allpSpots.get(0).getLongitude());
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(firstLocation, 13));
        }

        Button btnWallet = findViewById(R.id.BtnWall);

     /*   Intent intent = new Intent(MapsActivity.this, PocketActivity.class);
        double currentBalance = 0;
        intent.putExtra("balance", currentBalance);  // στέλνεις το ποσό

      */

        btnWallet.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intentW = new Intent(MapsActivity.this, PocketActivity.class);
                startActivity(intentW);
                // Optional: μπορείς να στείλεις δεδομένα
                intentW.putExtra("walletAmount", walletAmount);
                startActivityForResult(intentW,1);
            }
        });

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {

                ParkingSpot selectedSpot = markerParkingSpotMap.get(marker);

                if(selectedSpot != null){

                    tvPrice.setText("Τιμή: €"+ selectedSpot.getPricePerHour());
                    if (selectedSpot.isAvailable) {

                        String fullText = "Διαθεσιμότητα: Διαθέσιμη";
                        SpannableString spannable = new SpannableString(fullText);

                        // Βρίσκουμε τη θέση της λέξης "Διαθέσιμη"
                        int start = fullText.indexOf("Διαθέσιμη");
                        int end = start + "Διαθέσιμη".length();

                        // Ορίζουμε το χρώμα μόνο για τη λέξη "Διαθέσιμη"
                        spannable.setSpan(new ForegroundColorSpan(Color.GREEN), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                        // Βάζουμε το Spannable στο TextView
                        tvAvailability.setText(spannable);

                    }else{
                        String fullText = "Διαθεσιμότητα: Μη Διαθέσιμη";
                        SpannableString spannable = new SpannableString(fullText);

                        // Βρίσκουμε τη θέση της λέξης "Διαθέσιμη"
                        int start = fullText.indexOf("Μη Διαθέσιμη");
                        int end = start + "Μη Διαθέσιμη".length();

                        // Ορίζουμε το χρώμα μόνο για τη λέξη "Διαθέσιμη"
                        spannable.setSpan(new ForegroundColorSpan(Color.RED), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                        // Βάζουμε το Spannable στο TextView
                        tvAvailability.setText(spannable);
                    }
                    tvHours.setText("Ώρες λειτουργίας: "+ selectedSpot.getStartTime() + "-" + selectedSpot.getEndTime());
                    tvId.setText("ID Θέσης: "+ selectedSpot.getId());

                    btnRes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (selectedSpot.isAvailable) {
                                LocalTime total = selectedSpot.getEndTime().minusHours(selectedSpot.getStartTime().getHour()).minusMinutes(selectedSpot.getStartTime().getMinute());
                                long totalHours = total.getHour();
                                double totalCost = totalHours * selectedSpot.getPricePerHour();

                                if (totalCost <= walletAmount ) {
                                    Toast.makeText(MapsActivity.this, "Η κράτηση πραγματοποιήθηκε! ", Toast.LENGTH_SHORT).show();
                                    walletAmount = walletAmount - totalCost;
                                    selectedSpot.isAvailable = false;
                                    SharedPreferences prefs = getSharedPreferences("walletPrefs", MODE_PRIVATE);
                                    Gson gson = new Gson();

                                    // Ανάκτηση υπαρχόντων συναλλαγών
                                    String json = prefs.getString("transactionList", null);
                                    Type type = new TypeToken<ArrayList<String>>() {}.getType();
                                    ArrayList<String> transactions = gson.fromJson(json, type);

                                    if (transactions == null) {
                                        transactions = new ArrayList<>();
                                    }

                                    // Δημιουργία νέας συναλλαγής
                                    String newEntry = "Κράτηση θέσης ID " + selectedSpot.getId() + " - Χρέωση €" + totalCost;
                                    transactions.add(newEntry); // μπορείς να κάνεις add(0, newEntry) για να μπαίνει στην αρχή

// Αποθήκευση πίσω σε SharedPreferences
                                    String updatedJson = gson.toJson(transactions);
                                    prefs.edit().putString("transactionList", updatedJson).apply();
                                } else {
                                    Toast.makeText(MapsActivity.this, "Το υπόλοιπο σου δεν επαρκεί.", Toast.LENGTH_SHORT).show();
                                }
                            }else{
                                Toast.makeText(MapsActivity.this, "Η Θέση είναι κρατημένη.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
                return false;
            }
        });
        // (Προαιρετικά) Listener για κλικ σε marker
        // mMap.setOnMarkerClickListener(marker -> {
        //    ParkingSpot selectedSpot = markerParkingSpotMap.get(marker);
        //    if (selectedSpot != null) {
        //        // Εμφάνιση πληροφοριών για την επιλεγμένη θέση
        //       android.util.Log.d("ParkingSpot Info", "ID: " + selectedSpot.getId() + ", Τιμή: " + selectedSpot.getPricePerHour() + "€" + "Open from:" + selectedSpot.getStartTime()+ "To" + selectedSpot.getEndTime() +  ", Available: " + selectedSpot.isAvailable);
        //       // Μπορείς να εμφανίσεις ένα InfoWindow ή ένα custom UI εδώ
        //   }
        //    return false; // Επιστρέφει false για να συνεχίσει η προεπιλεγμένη συμπεριφορά (π.χ., εμφάνιση του info window αν υπάρχει)
        // });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            walletAmount = data.getDoubleExtra("walletAmount", 0.0);
            // Τώρα έχεις το ποσό -> walletAmount
            Toast.makeText(this, "Υπόλοιπο: €" + walletAmount, Toast.LENGTH_SHORT).show();
        }
    }

}

